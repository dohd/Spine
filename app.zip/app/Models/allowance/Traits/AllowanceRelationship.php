<?php

namespace App\Models\allowance\Traits;


/**
 * Class DepartmentRelationship
 */
trait AllowanceRelationship
{
     
}
