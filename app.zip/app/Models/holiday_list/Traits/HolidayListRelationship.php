<?php

namespace App\Models\holiday_list\Traits;

trait HolidayListRelationship
{
    
}
