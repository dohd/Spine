<?php

namespace App\Models\event\Traits;

/**
 * Class EventRelationship
 */
trait EventRelationship
{

}
