<?php

namespace App\Models\employeeallowance\Traits;


/**
 * Class DepartmentRelationship
 */
trait EmployeeAllowanceRelationship
{
    
}
