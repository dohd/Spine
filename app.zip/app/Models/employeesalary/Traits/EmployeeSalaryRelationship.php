<?php

namespace App\Models\employeesalary\Traits;


/**
 * Class NhifRelationship
 */
trait EmployeeSalaryRelationship
{
    
}
