<?php

namespace App\Models\leave_category\Traits;

trait LeaveCategoryRelationship
{
    
}
