<?php

namespace App\Models\schedule_equipment;

use Illuminate\Database\Eloquent\Model;

class ScheduleEquipment extends Model
{
    //
}
