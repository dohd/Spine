<?php

namespace App\Models\items\Traits;


/**
 * Class CustomerRelationship
 */
trait DjcItemRelationship
{

       public function equipment()
    {
       // return $this->belongsTo('App\Models\equipment\Equipment','product_id','product_id');
    }

      

}
