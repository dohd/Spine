<?php

namespace App\Models\nssf\Traits;


/**
 * Class NssfRelationship
 */
trait NssfRelationship
{
    
}
