<?php

namespace App\Models\paye\Traits;


/**
 * Class NhifRelationship
 */
trait PayeRelationship
{
    
}
