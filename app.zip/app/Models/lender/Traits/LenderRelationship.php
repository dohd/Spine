<?php

namespace App\Models\lender\Traits;




/**
 * Class LenderRelationship
 */
trait LenderRelationship
{
  
}
