<?php

namespace App\Models\nhif\Traits;


/**
 * Class NhifRelationship
 */
trait NhifRelationship
{
    
}
