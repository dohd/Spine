<?php

namespace App\Models\template\Traits;

/**
 * Class TemplateRelationship
 */
trait TemplateRelationship
{

}
