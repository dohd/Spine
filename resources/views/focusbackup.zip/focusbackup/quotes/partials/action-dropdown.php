<div class="dropdown">
    <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Action
    </button>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item add-title" href="javascript:"><i class="fa fa-plus"></i> Title</a>
        <a class="dropdown-item add-product" href="javascript:"><i class="fa fa-plus"></i> Product</a>
        <a class="dropdown-item add-misc" href="javascript:"><i class="fa fa-plus"></i> Miscellaneous</a>
        <hr>
        <a class="dropdown-item up" href="javascript:">Up</a>
        <a class="dropdown-item down" href="javascript:">Down</a>
        <a class="dropdown-item text-danger delete" href="javascript:">Remove</a>
    </div>
</div> 