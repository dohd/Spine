{!! json_encode($details) !!}
