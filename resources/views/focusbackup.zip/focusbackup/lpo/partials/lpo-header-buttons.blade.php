<div>
    <div class="btn-group">
        <a href="#" class="btn btn-info w-2" id="addt" data-toggle="modal" data-target="#AddLpoModal">
            <i class="fa fa-plus-circle"></i> Create
        </a>        
    </div>
</div>
