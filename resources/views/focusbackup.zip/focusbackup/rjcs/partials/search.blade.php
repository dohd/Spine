{!! json_encode($details) !!}
