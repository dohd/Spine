<?php
return [
'class'=>'třída',
'module'=>'Modul',
'value'=>'Hodnota',
'note'=>'Poznámka',
'prefixes'=>'Předpony',
'prefix'=>'Předpona',
'invoice'=>'Faktura',
'delivery_note'=>'Dodací list',
'proforma_invoice'=>'Faktura proforma',
'payment_receipt'=>'Účtenka',
'quotes'=>'Citáty',
'subscriptions'=>'Předplatné',
'credit_note'=>'Dobropis',
'stock_return'=>'Vracení akcií',
'purchase_order'=>'Nákupní objednávka',
'POS'=>'POS Point Of Sale',
];
