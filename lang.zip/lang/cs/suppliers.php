<?php
return [
'management'=>'Řízení dodavatelů',
'suppliers'=>'Dodavatelé',
'supplier'=>'Dodavatel',
'valid_enter'=>'Vyberte prosím platného dodavatele!',
];
