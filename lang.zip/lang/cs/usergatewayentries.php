<?php
return [
'gateway'=>'Brána',
'enable'=>'Umožnit',
'key1'=>'Klíč 1',
'key2'=>'Klíč 2',
'currency'=>'Kód měny',
'dev_mode'=>'Vývojářský režim',
'surcharge'=>'Přirážka%',
'extra'=>'jiný',
'usergatewayentries'=>'Platební brány',
'usergatewayentry'=>'Platební brána',
'surcharge_applicable'=>'Příplatek za platební bránu Platí pro celkovou částku',
];
