<?php
return [
'title'=>'Kategorie',
'extra'=>'Popis',
'sub_category'=>'Podkategorie',
'sub_categories'=>'Dílčí kategorie',
'total_products'=>'Celkem produktů',
'total_worth'=>'Celková hodnota',
'c_type'=>'Typ kategorie',
'rel_id'=>'Rodičovská Kategorie',
'parent'=>'Rodič',
'child'=>'Dítě',
'productcategories'=>'kategorie produktů',
'valid_enter'=>'Vyberte prosím platnou kategorii produktu!',
];
