<?php
return [
'name'=>'název',
'transactioncategories'=>'Kategorie transakcí',
'transactioncategory'=>'Kategorie transakce',
'valid_enter'=>'Vyberte prosím platnou kategorii transakcí!',
];
