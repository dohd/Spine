<?php
return [
'name'=>'název',
'color'=>'Barva',
'section'=>'Sekce',
'miscs'=>'Značky a statusy',
'misc'=>'Značka a stav',
];
