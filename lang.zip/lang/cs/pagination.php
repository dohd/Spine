<?php
return [
'previous'=>'«Předchozí',
'next'=>'Další "',
];
