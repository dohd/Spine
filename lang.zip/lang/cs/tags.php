<?php
return [
'name'=>'Název štítku',
'tags'=>'Značky',
'tag'=>'Štítek',
'new'=>'Nová značka',
'color'=>'Barva značky',
'select'=>'Vyberte tag ..',
'new_status'=>'Nový stav',
'tag_status'=>'Stav a značky',
];
