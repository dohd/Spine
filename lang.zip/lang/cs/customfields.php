<?php
return [
'module_id'=>'Modul',
'field_type'=>'Typ pole',
'name'=>'název',
'placeholder'=>'Zástupný symbol',
'default_data'=>'Výchozí data',
'field_view'=>'Field view',
'customfields'=>'Vlastní pole',
'customfield'=>'Vlastní pole',
'text'=>'Text',
'public'=>'Veřejnost',
'private'=>'Soukromé',
];
