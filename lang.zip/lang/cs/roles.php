<?php
return [
'administrator'=>'Správce',
'user'=>'Uživatel',
];
