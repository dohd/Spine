<?php
return [
'name'=>'Jméno účtu',
'bank'=>'banka',
'number'=>'Číslo bankovního účtu',
'code'=>'Kód účtu',
'note'=>'Poznámka',
'address'=>'Adresa pobočky',
'branch'=>'Větev',
'enable'=>'Umožnit',
'banks'=>'Bankovní účty',
'payable_accounts'=>'Splatné účty',
];
