<?php
return [
'management'=>'Objednávky',
'tid'=>'Číslo objednávky',
'invoicedate'=>'Datum objednávky',
'invoiceduedate'=>'Datum potvrzení objednávky',
'search_supplier'=>'Vyhledat dodavatele',
'supplier_details'=>'Podrobnosti o dodavateli',
'supplier_search'=>'Chcete-li hledat, zadejte jméno dodavatele nebo mobilní číslo',
'add_supplier'=>'Přidat dodavatele',
'properties'=>'Vlastnosti',
'bill_from'=>'Bill od',
'payment_for_order'=>'Platba za objednávku',
'purchaseorders'=>'Objednávky',
'purchaseorder'=>'Nákupní objednávka',
];
