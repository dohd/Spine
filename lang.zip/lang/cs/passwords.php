<?php
return [
'password'=>'Hesla musí mít alespoň šest znaků a musí odpovídat potvrzení.',
'reset'=>'Vaše heslo bylo resetováno!',
'sent'=>'Odkaz na resetování hesla jsme vám zaslali e-mailem!',
'token'=>'Tento token pro resetování hesla je neplatný.',
'user'=>'Nemůžeme najít uživatele s touto e-mailovou adresou.',
];
