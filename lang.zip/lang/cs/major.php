<?php
return [
'address_1'=>'Adresa 1',
'address_2'=>'Adresa 2',
'city'=>'Město',
'state'=>'Stát',
'country'=>'Země',
'postal'=>'Poštovní',
'company'=>'Společnost',
'tax_id'=>'DIČ',
'contact'=>'Kontakt',
'price'=>'Cena',
];
