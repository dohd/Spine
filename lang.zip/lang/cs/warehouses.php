<?php
return [
'warehouse'=>'Sklad',
'warehouse_default'=>'Výchozí sklad',
'warehouses'=>'Sklad',
'title'=>'Název WareHouse',
'extra'=>'Popis WareHouse',
'valid_enter'=>'Vyberte platný sklad!',
];
