<?php 
return [
  'failed' => 'Tyto údaje se neshodují s našimi záznamy.',
  'general_error' => 'K tomu nemáte přístup.',
  'throttle' => 'Příliš mnoho pokusů o přihlášení. Zkuste to prosím znovu za: sekund sekund.',
  'unknown' => 'Nastala neznámá chyba',
];