<?php
return [
'title'=>'název',
'summary'=>'souhrn',
'disc_rate'=>'Skupinová diskontní sazba',
'members'=>'Členové',
'group_message'=>'Odeslat skupinovou zprávu',
];
