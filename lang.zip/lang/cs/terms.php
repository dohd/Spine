<?php
return [
'title'=>'Titul',
'type'=>'Modul',
'terms'=>'Podmínky',
'term'=>'Období',
'required'=>'Vytvořte a vyberte platební termín!',
];
