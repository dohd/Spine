<?php
return [
'name'=>'název',
'code'=>'Kód',
'type'=>'Typ',
'val'=>'Hodnota',
'rid'=>'Související s',
'unit_default'=>'Výchozí jednotka',
'productvariables'=>'Proměnné jednotek produktu',
'productvariable'=>'Proměnná jednotky produktu',
'standard_type'=>'Standardní typ - jednotlivá jednotka',
'multiple_type'=>'Více typů - více jednotek',
];
