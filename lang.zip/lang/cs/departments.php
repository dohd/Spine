<?php
return [
'name'=>'název',
'note'=>'Poznámka',
'departments'=>'Oddělení',
'department'=>'oddělení',
];
