<?php
return [
'home'=>'Domov',
'plans'=>'Plány',
'blog'=>'Blog',
'about'=>'O',
'contact'=>'Kontakt',
'register_now'=>'Zaregistrujte se nyní',
'pricing_plans'=>'Naše cenové plány',
'sign_up'=>'Přihlásit se',
'subscribe'=>'předplatit',
'renew'=>'Plán obnovy',
'subscribe_exist'=>'Tento plán jste již přihlášili!',
'make_payment'=>'Proveďte platbu a potvrďte předplatné',
];
