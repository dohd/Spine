<?php
return [
'previous'=>'«前へ',
'next'=>'次 "',
];
