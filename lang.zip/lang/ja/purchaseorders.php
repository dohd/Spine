<?php
return [
'management'=>'発注書',
'tid'=>'発注番号',
'invoicedate'=>'注文日',
'invoiceduedate'=>'注文確認日',
'search_supplier'=>'サプライヤーを検索',
'supplier_details'=>'サプライヤーの詳細',
'supplier_search'=>'検索するサプライヤー名または携帯番号を入力してください',
'add_supplier'=>'サプライヤーを追加',
'properties'=>'プロパティ',
'bill_from'=>'ビルから',
'payment_for_order'=>'注文の支払い',
'purchaseorders'=>'発注書',
'purchaseorder'=>'注文書',
];
