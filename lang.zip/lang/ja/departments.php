<?php
return [
'name'=>'名前',
'note'=>'注意',
'departments'=>'部門',
'department'=>'部門',
];
