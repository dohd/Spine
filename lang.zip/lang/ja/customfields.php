<?php
return [
'module_id'=>'モジュール',
'field_type'=>'フィールドタイプ',
'name'=>'名前',
'placeholder'=>'プレースホルダー',
'default_data'=>'デフォルトデータ',
'field_view'=>'フィールドビュー',
'customfields'=>'カスタムフィールド',
'customfield'=>'カスタムフィールド',
'text'=>'テキスト',
'public'=>'公衆',
'private'=>'民間',
];
