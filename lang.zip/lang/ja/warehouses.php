<?php
return [
'warehouse'=>'倉庫',
'warehouse_default'=>'デフォルトの倉庫',
'warehouses'=>'倉庫',
'title'=>'倉庫名',
'extra'=>'倉庫の説明',
'valid_enter'=>'有効な倉庫を選択してください！',
];
