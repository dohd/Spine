<?php
return [
'title'=>'題名',
'type'=>'モジュール',
'terms'=>'条項',
'term'=>'期間',
'required'=>'支払条件を作成して選択してください！',
];
