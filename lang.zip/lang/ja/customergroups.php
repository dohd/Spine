<?php
return [
'title'=>'名前',
'summary'=>'概要',
'disc_rate'=>'グループ割引率',
'members'=>'会員',
'group_message'=>'グループメッセージを送信',
];
