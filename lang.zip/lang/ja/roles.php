<?php
return [
'administrator'=>'管理者',
'user'=>'ユーザー',
];
