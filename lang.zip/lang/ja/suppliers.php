<?php
return [
'management'=>'サプライヤー管理',
'suppliers'=>'サプライヤー',
'supplier'=>'サプライヤー',
'valid_enter'=>'有効なサプライヤーを選択してください！',
];
