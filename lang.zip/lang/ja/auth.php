<?php 
return [
  'failed' => 'これらの資格情報は記録と一致しません。',
  'general_error' => 'そのためのアクセス権がありません。',
  'throttle' => 'ログイン試行が多すぎます。 ：seconds秒後にもう一度お試しください。',
  'unknown' => '不明なエラーが発生しました',
];