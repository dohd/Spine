<?php
return [
'home'=>'ホーム',
'plans'=>'予定',
'blog'=>'ブログ',
'about'=>'約',
'contact'=>'連絡先',
'register_now'=>'今すぐ登録',
'pricing_plans'=>'価格プラン',
'sign_up'=>'サインアップ',
'subscribe'=>'申し込む',
'renew'=>'更新計画',
'subscribe_exist'=>'あなたはすでにこのプランを購読しています！',
'make_payment'=>'サブスクリプションを確認するために支払いを行う',
];
