<?php
return [
'name'=>'タグ名',
'tags'=>'タグ',
'tag'=>'鬼ごっこ',
'new'=>'新しいタグ',
'color'=>'タグの色',
'select'=>'タグを選択します。',
'new_status'=>'新しいステータス',
'tag_status'=>'ステータスとタグ',
];
