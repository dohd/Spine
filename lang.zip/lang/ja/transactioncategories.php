<?php
return [
'name'=>'名前',
'transactioncategories'=>'取引カテゴリ',
'transactioncategory'=>'取引区分',
'valid_enter'=>'有効な取引カテゴリを選択してください！',
];
