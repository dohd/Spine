<?php
return [
'title'=>'カテゴリー',
'extra'=>'説明',
'sub_category'=>'サブカテゴリー',
'sub_categories'=>'サブカテゴリー',
'total_products'=>'トータル製品',
'total_worth'=>'総価値',
'c_type'=>'カテゴリーの種類',
'rel_id'=>'親カテゴリ',
'parent'=>'親',
'child'=>'子',
'productcategories'=>'製品カテゴリ',
'valid_enter'=>'有効な製品カテゴリを選択してください！',
];
