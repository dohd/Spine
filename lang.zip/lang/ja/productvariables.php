<?php
return [
'name'=>'名前',
'code'=>'コード',
'type'=>'タイプ',
'val'=>'値',
'rid'=>'関連する',
'unit_default'=>'デフォルト単位',
'productvariables'=>'製品単位変数',
'productvariable'=>'製品単位変数',
'standard_type'=>'標準タイプ-シングルユニット',
'multiple_type'=>'複数タイプ-複数ユニット',
];
