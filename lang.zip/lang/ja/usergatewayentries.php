<?php
return [
'gateway'=>'ゲートウェイ',
'enable'=>'有効にする',
'key1'=>'キー1',
'key2'=>'キー2',
'currency'=>'通貨コード',
'dev_mode'=>'開発者モード',
'surcharge'=>'サーチャージ％',
'extra'=>'その他',
'usergatewayentries'=>'支払いゲートウェイ',
'usergatewayentry'=>'支払いゲートウェイ',
'surcharge_applicable'=>'合計金額に適用される支払いゲートウェイの追加料金',
];
