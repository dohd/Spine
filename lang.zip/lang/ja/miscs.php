<?php
return [
'name'=>'名前',
'color'=>'色',
'section'=>'セクション',
'miscs'=>'タグとステータス',
'misc'=>'タグとステータス',
];
