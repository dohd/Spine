<?php
return [
'name'=>'アカウント名',
'bank'=>'バンク',
'number'=>'銀行の口座番号',
'code'=>'口座番号',
'note'=>'注意',
'address'=>'支店住所',
'branch'=>'ブランチ',
'enable'=>'有効にする',
'banks'=>'銀行口座',
'payable_accounts'=>'買掛金勘定',
];
