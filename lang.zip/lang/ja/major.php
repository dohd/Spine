<?php
return [
'address_1'=>'住所（1',
'address_2'=>'アドレス2',
'city'=>'市',
'state'=>'状態',
'country'=>'国',
'postal'=>'郵便',
'company'=>'会社',
'tax_id'=>'納税者番号',
'contact'=>'連絡先',
'price'=>'価格',
];
