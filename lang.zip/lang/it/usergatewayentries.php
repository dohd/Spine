<?php
return [
'gateway'=>'Gateway',
'enable'=>'Enable',
'key1'=>'Key 1',
'key2'=>'Key 2',
'currency'=>'Currency Code',
'dev_mode'=>'Developer mode',
'surcharge'=>'Surcharge %',
'extra'=>'Other',
'usergatewayentries'=>'Payment Gateways',
'usergatewayentry'=>'Casello stradale',
'surcharge_applicable'=>'Supplemento gateway di pagamento Applicabile sull"importo totale',
];
