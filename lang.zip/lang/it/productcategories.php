<?php
return [
'title'=>'Categoria',
'extra'=>'Descrizione',
'sub_category'=>'Sottocategoria',
'sub_categories'=>'Sottocategorie',
'total_products'=>'Totale prodotti',
'total_worth'=>'Valore totale',
'c_type'=>'Tipo di categoria',
'rel_id'=>'Categoria principale',
'parent'=>'Genitore',
'child'=>'Bambino',
'productcategories'=>'Categorie di Prodotto',
'valid_enter'=>'Seleziona una categoria di prodotti valida!',
];
