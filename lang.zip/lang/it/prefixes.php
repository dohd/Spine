<?php
return [
'class'=>'classe',
'module'=>'Modulo',
'value'=>'Valore',
'note'=>'Nota',
'prefixes'=>'prefissi',
'prefix'=>'Prefisso',
'invoice'=>'Fattura',
'delivery_note'=>'Bolla d"accompagnamento',
'proforma_invoice'=>'Fattura proforma',
'payment_receipt'=>'Ricevuta di pagamento',
'quotes'=>'Citazioni',
'subscriptions'=>'Sottoscrizioni',
'credit_note'=>'Nota di credito',
'stock_return'=>'Resi di magazzino',
'purchase_order'=>'Ordinazione d"acquisto',
'POS'=>'Punto vendita POS',
];
