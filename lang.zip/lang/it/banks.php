<?php
return [
'name'=>'Nome utente',
'bank'=>'Banca',
'number'=>'Numero di conto bancario',
'code'=>'Codice dell"account',
'note'=>'Nota',
'address'=>'Indirizzo di filiale',
'branch'=>'Ramo',
'enable'=>'Abilitare',
'banks'=>'Conto in banca',
'payable_accounts'=>'Contabilità fornitori',
];
