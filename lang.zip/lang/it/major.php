<?php
return [
'address_1'=>'Indirizzo 1',
'address_2'=>'Indirizzo 2',
'city'=>'Città',
'state'=>'Stato',
'country'=>'Nazione',
'postal'=>'postale',
'company'=>'Azienda',
'tax_id'=>'ID FISCALE',
'contact'=>'Contatto',
'price'=>'Prezzo',
];
