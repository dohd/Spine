<?php
return [
'management'=>'Purchase Orders',
'tid'=>'Purchase Order Number',
'invoicedate'=>'Orders date',
'invoiceduedate'=>'Orders confirm date',
'search_supplier'=>'Search supplier',
'supplier_details'=>'Supplier Details',
'supplier_search'=>'Enter Supplier Name or Mobile Number to search',
'add_supplier'=>'Add Supplier',
'properties'=>'Properties',
'bill_from'=>'Bill From',
'payment_for_order'=>'Payment for Purchase order',
'purchaseorders'=>'Purchase Orders',
'purchaseorder'=>'Purchase Order',
];
