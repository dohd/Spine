<?php
return [
'name'=>'Nome',
'color'=>'Colore',
'section'=>'Sezione',
'miscs'=>'Tag e stati',
'misc'=>'Tag e stato',
];
