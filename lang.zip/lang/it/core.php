<?php
return [
'home'=>'Casa',
'plans'=>'Piani',
'blog'=>'blog',
'about'=>'Di',
'contact'=>'Contatto',
'register_now'=>'Iscriviti ora',
'pricing_plans'=>'I nostri piani tariffari',
'sign_up'=>'Iscriviti',
'subscribe'=>'sottoscrivi',
'renew'=>'Rinnova piano',
'subscribe_exist'=>'Hai già sottoscritto questo piano!',
'make_payment'=>'Effettua il pagamento per confermare l"abbonamento',
];
