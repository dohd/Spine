<?php
return [
'previous'=>'«Precedente',
'next'=>'Il prossimo "',
];
