<?php
return [
'module_id'=>'Modulo',
'field_type'=>'Tipo di campo',
'name'=>'Nome',
'placeholder'=>'segnaposto',
'default_data'=>'Dati predefiniti',
'field_view'=>'Field View',
'customfields'=>'Campi personalizzati',
'customfield'=>'Campo personalizzato',
'text'=>'Testo',
'public'=>'Pubblico',
'private'=>'Privato',
];
