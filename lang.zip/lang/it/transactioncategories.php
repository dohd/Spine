<?php
return [
'name'=>'Name',
'transactioncategories'=>'Transaction categories',
'transactioncategory'=>'Transaction category',
'valid_enter'=>'Please select a valid Transaction category!',
];
