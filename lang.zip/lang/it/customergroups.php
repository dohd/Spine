<?php
return [
'title'=>'Nome',
'summary'=>'Sommario',
'disc_rate'=>'Tasso di sconto del gruppo',
'members'=>'Membri',
'group_message'=>'Invia un messaggio di gruppo',
];
