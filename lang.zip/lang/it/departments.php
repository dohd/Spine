<?php
return [
'name'=>'Nome',
'note'=>'Nota',
'departments'=>'dipartimenti',
'department'=>'Dipartimento',
];
