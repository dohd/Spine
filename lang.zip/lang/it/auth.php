<?php 
return [
  'failed' => 'Queste credenziali non corrispondono ai nostri record.',
  'general_error' => 'Non hai accesso per farlo.',
  'throttle' => 'Troppi tentativi di accesso. Riprova tra: secondi secondi.',
  'unknown' => 'Si è verificato un errore sconosciuto',
];