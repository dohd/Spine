<?php
return [
'warehouse'=>'Magazzino',
'warehouse_default'=>'Magazzino predefinito',
'warehouses'=>'Magazzino',
'title'=>'Nome del magazzino',
'extra'=>'Descrizione del magazzino',
'valid_enter'=>'Seleziona un magazzino valido!',
];
