<?php
return [
'title'=>'Categorie',
'extra'=>'Descriere',
'sub_category'=>'Subcategorie',
'sub_categories'=>'Subcategorii',
'total_products'=>'Total produse',
'total_worth'=>'Valoarea totală',
'c_type'=>'Tip de categorie',
'rel_id'=>'Categoria părinților',
'parent'=>'Mamă',
'child'=>'Copil',
'productcategories'=>'Categorii de produse',
'valid_enter'=>'Vă rugăm să selectați o categorie de produs validă!',
];
