<?php
return [
'home'=>'Acasă',
'plans'=>'Planuri',
'blog'=>'Blog',
'about'=>'Despre',
'contact'=>'a lua legatura',
'register_now'=>'Înregistrează-te acum',
'pricing_plans'=>'Planurile noastre de stabilire a prețurilor',
'sign_up'=>'Inscrie-te',
'subscribe'=>'Abonati-va',
'renew'=>'Planul de reînnoire',
'subscribe_exist'=>'V-ați abonat deja la acest plan!',
'make_payment'=>'Efectuați plata pentru a confirma abonamentul',
];
