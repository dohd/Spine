<?php
return [
'title'=>'Titlu',
'type'=>'Modul',
'terms'=>'Termeni',
'term'=>'Termen',
'required'=>'Vă rugăm să creați și să selectați un termen de plată!',
];
