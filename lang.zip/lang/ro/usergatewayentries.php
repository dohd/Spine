<?php
return [
'gateway'=>'portal',
'enable'=>'Permite',
'key1'=>'Cheia 1',
'key2'=>'Cheia 2',
'currency'=>'Cod valutar',
'dev_mode'=>'Modul dezvoltator',
'surcharge'=>'Suprataxă %',
'extra'=>'Alte',
'usergatewayentries'=>'Gateway-uri de plată',
'usergatewayentry'=>'Gateway de plată',
'surcharge_applicable'=>'Suprataxă Gateway de plată Se aplică în totalitate',
];
