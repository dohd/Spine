<?php
return [
'management'=>'Ordine de achiziție',
'tid'=>'Numărul de ordine de cumpărare',
'invoicedate'=>'Data comenzilor',
'invoiceduedate'=>'Comenzile confirmă data',
'search_supplier'=>'Căutare furnizor',
'supplier_details'=>'Detalii furnizor',
'supplier_search'=>'Introduceți numele furnizorului sau numărul mobil pentru a căuta',
'add_supplier'=>'Adăugați furnizor',
'properties'=>'Proprietăți',
'bill_from'=>'Bill From',
'payment_for_order'=>'Plata pentru comanda de cumpărare',
'purchaseorders'=>'Ordine de achiziție',
'purchaseorder'=>'Comandă de achiziție',
];
