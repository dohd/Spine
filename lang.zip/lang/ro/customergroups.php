<?php
return [
'title'=>'Nume',
'summary'=>'rezumat',
'disc_rate'=>'Rata de reducere a grupului',
'members'=>'Membrii',
'group_message'=>'Trimite mesaj de grup',
];
