<?php
return [
'module_id'=>'Modul',
'field_type'=>'Tipul câmpului',
'name'=>'Nume',
'placeholder'=>'Substitut',
'default_data'=>'Date implicite',
'field_view'=>'Vizualizare câmp',
'customfields'=>'Câmpuri customizate',
'customfield'=>'Câmp personalizat',
'text'=>'Text',
'public'=>'Public',
'private'=>'Privat',
];
