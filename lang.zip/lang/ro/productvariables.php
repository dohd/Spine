<?php
return [
'name'=>'Nume',
'code'=>'Cod',
'type'=>'Tip',
'val'=>'Valoare',
'rid'=>'În legătură cu',
'unit_default'=>'Unitatea implicită',
'productvariables'=>'Variabilele unității de produs',
'productvariable'=>'Variabilă unitate de produs',
'standard_type'=>'Tip standard - unitate unică',
'multiple_type'=>'Multiple Type - Multiple Unit',
];
