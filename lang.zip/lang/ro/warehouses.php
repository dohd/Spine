<?php
return [
'warehouse'=>'Depozit',
'warehouse_default'=>'Depozit implicit',
'warehouses'=>'Depozit',
'title'=>'Numele WareHouse',
'extra'=>'WareHouse Descriere',
'valid_enter'=>'Vă rugăm să selectați un depozit valabil!',
];
