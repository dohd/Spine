<?php
return [
'previous'=>'«Anterior',
'next'=>'Următor → "',
];
