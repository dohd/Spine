<?php
return [
'address_1'=>'Adresa 1',
'address_2'=>'Adresa 2',
'city'=>'Oraș',
'state'=>'Stat',
'country'=>'Țară',
'postal'=>'Poştal',
'company'=>'Companie',
'tax_id'=>'ID FISCAL',
'contact'=>'a lua legatura',
'price'=>'Preț',
];
