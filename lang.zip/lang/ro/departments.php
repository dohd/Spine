<?php
return [
'name'=>'Nume',
'note'=>'Notă',
'departments'=>'departamente',
'department'=>'Departament',
];
