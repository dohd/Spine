<?php 
return [
  'failed' => 'Aceste acreditări nu se potrivesc cu înregistrările noastre.',
  'general_error' => 'Nu aveți acces pentru a face asta.',
  'throttle' => 'Prea multe încercări de conectare. Încercați din nou în: secunde.',
  'unknown' => 'O eroare necunoscută s-a întamplat',
];