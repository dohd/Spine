<?php
return [
'class'=>'clasă',
'module'=>'Modul',
'value'=>'Valoare',
'note'=>'Notă',
'prefixes'=>'Prefixele',
'prefix'=>'Prefix',
'invoice'=>'Factura fiscala',
'delivery_note'=>'Aviz de expeditie',
'proforma_invoice'=>'Factura proforma',
'payment_receipt'=>'Chitanta de plata',
'quotes'=>'Citate',
'subscriptions'=>'Abonamente',
'credit_note'=>'Nota de credit',
'stock_return'=>'Returnări ale stocurilor',
'purchase_order'=>'Comandă de achiziție',
'POS'=>'Punct de vânzare POS',
];
