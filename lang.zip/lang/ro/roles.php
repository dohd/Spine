<?php
return [
'administrator'=>'Administrator',
'user'=>'Utilizator',
];
