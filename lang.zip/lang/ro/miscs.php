<?php
return [
'name'=>'Nume',
'color'=>'Culoare',
'section'=>'Secțiune',
'miscs'=>'Etichete & Statute',
'misc'=>'Etichetă și stare',
];
