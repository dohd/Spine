<?php
return [
'name'=>'Nume eticheta',
'tags'=>'Etichete',
'tag'=>'Etichetă',
'new'=>'Noua etichetă',
'color'=>'Culoare etichetă',
'select'=>'Selectați eticheta ..',
'new_status'=>'Statut nou',
'tag_status'=>'Stare și etichete',
];
