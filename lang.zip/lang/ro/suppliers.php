<?php
return [
'management'=>'Managementul furnizorilor',
'suppliers'=>'Furnizori',
'supplier'=>'Furnizor',
'valid_enter'=>'Vă rugăm să selectați un furnizor valid!',
];
