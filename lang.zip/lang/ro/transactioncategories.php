<?php
return [
'name'=>'Nume',
'transactioncategories'=>'Categorii de tranzacții',
'transactioncategory'=>'Categoria tranzacției',
'valid_enter'=>'Vă rugăm să selectați o categorie de tranzacție valabilă!',
];
