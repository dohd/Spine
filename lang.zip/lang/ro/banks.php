<?php
return [
'name'=>'Nume de cont',
'bank'=>'bancă',
'number'=>'Numarul contului bancar',
'code'=>'Codul contului',
'note'=>'Notă',
'address'=>'Adresa filialei',
'branch'=>'ramură',
'enable'=>'Permite',
'banks'=>'Conturi bancare',
'payable_accounts'=>'Conturi plătibile',
];
