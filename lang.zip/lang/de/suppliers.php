<?php
return [
'management'=>'Lieferantenmanagement',
'suppliers'=>'Lieferanten',
'supplier'=>'Lieferant',
'valid_enter'=>'Bitte wählen Sie einen gültigen Lieferanten!',
];
