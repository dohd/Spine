<?php
return [
'name'=>'Name',
'transactioncategories'=>'Transaktionskategorien',
'transactioncategory'=>'Transaktionskategorie',
'valid_enter'=>'Bitte wählen Sie eine gültige Transaktionskategorie!',
];
