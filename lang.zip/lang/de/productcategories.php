<?php
return [
'title'=>'Kategorie',
'extra'=>'Beschreibung',
'sub_category'=>'Unterkategorie',
'sub_categories'=>'Unterkategorien',
'total_products'=>'Produkte insgesamt',
'total_worth'=>'Gesamtwert',
'c_type'=>'Kategorietyp',
'rel_id'=>'Eltern-Kategorie',
'parent'=>'Elternteil',
'child'=>'Kind',
'productcategories'=>'Produktkategorien',
'valid_enter'=>'Bitte wählen Sie eine gültige Produktkategorie!',
];
