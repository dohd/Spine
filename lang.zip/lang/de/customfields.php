<?php
return [
'module_id'=>'Modul',
'field_type'=>'Feldtyp',
'name'=>'Name',
'placeholder'=>'Platzhalter',
'default_data'=>'Standarddaten',
'field_view'=>'Feldansicht',
'customfields'=>'Benutzerdefinierte Felder',
'customfield'=>'Benutzerdefinierte Feld',
'text'=>'Text',
'public'=>'Öffentlichkeit',
'private'=>'Privat',
];
