<?php
return [
'home'=>'Zuhause',
'plans'=>'Pläne',
'blog'=>'Blog',
'about'=>'Über',
'contact'=>'Kontakt',
'register_now'=>'Jetzt registrieren',
'pricing_plans'=>'Unsere Preispläne',
'sign_up'=>'Anmelden',
'subscribe'=>'Abonnieren',
'renew'=>'Plan erneuern',
'subscribe_exist'=>'Sie haben diesen Plan bereits abonniert!',
'make_payment'=>'Zahlung leisten, um das Abonnement zu bestätigen',
];
