<?php
return [
'warehouse'=>'Warenhaus',
'warehouse_default'=>'Standardlager',
'warehouses'=>'Warenhaus',
'title'=>'WareHouse Name',
'extra'=>'WareHouse Beschreibung',
'valid_enter'=>'Bitte wählen Sie ein gültiges Lager!',
];
