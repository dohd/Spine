<?php
return [
'name'=>'Name',
'note'=>'Hinweis',
'departments'=>'Abteilungen',
'department'=>'Abteilung',
];
