<?php
return [
'administrator'=>'Administrator',
'user'=>'Benutzer',
];
