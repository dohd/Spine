<?php
return [
'management'=>'Kauforder',
'tid'=>'Bestellnummer',
'invoicedate'=>'Bestelldatum',
'invoiceduedate'=>'Bestellungen bestätigen Datum',
'search_supplier'=>'Lieferanten suchen',
'supplier_details'=>'Lieferantendetails',
'supplier_search'=>'Geben Sie den Lieferantennamen oder die Handynummer für die Suche ein',
'add_supplier'=>'Lieferanten hinzufügen',
'properties'=>'Eigenschaften',
'bill_from'=>'Bill From',
'payment_for_order'=>'Zahlung für Bestellung',
'purchaseorders'=>'Kauforder',
'purchaseorder'=>'Bestellung',
];
