<?php
return [
'name'=>'Kontobezeichnung',
'bank'=>'Bank',
'number'=>'Kontonummer',
'code'=>'Konto Code',
'note'=>'Hinweis',
'address'=>'Anschrift der Niederlassung',
'branch'=>'Ast',
'enable'=>'Aktivieren',
'banks'=>'Bankkonten',
'payable_accounts'=>'Kreditorenbuchhaltung',
];
