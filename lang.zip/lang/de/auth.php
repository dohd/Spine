<?php 
return [
  'failed' => 'Diese Anmeldeinformationen stimmen nicht mit unseren Aufzeichnungen überein.',
  'general_error' => 'Sie haben keinen Zugriff darauf.',
  'throttle' => 'Zu viele Anmeldeversuche. Bitte versuchen Sie es erneut in: Sekunden Sekunden.',
  'unknown' => 'Ein unbekannter Fehler ist aufgetreten',
];