<?php
return [
'title'=>'Titel',
'type'=>'Modul',
'terms'=>'Bedingungen',
'term'=>'Begriff',
'required'=>'Bitte erstellen und wählen Sie eine Zahlungsbedingung!',
];
