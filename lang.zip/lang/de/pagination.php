<?php
return [
'previous'=>'" Bisherige',
'next'=>'Nächster "',
];
