<?php
return [
'title'=>'Name',
'summary'=>'Zusammenfassung',
'disc_rate'=>'Gruppenrabatt',
'members'=>'Mitglieder',
'group_message'=>'Gruppennachricht senden',
];
