<?php
return [
'name'=>'Name',
'code'=>'Code',
'type'=>'Art',
'val'=>'Wert',
'rid'=>'Im Zusammenhang mit',
'unit_default'=>'Standardeinheit',
'productvariables'=>'Variablen der Produkteinheiten',
'productvariable'=>'Produkteinheitsvariable',
'standard_type'=>'Standardtyp - Einzeleinheit',
'multiple_type'=>'Multiple Type - Mehrere Einheiten',
];
