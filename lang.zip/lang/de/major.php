<?php
return [
'address_1'=>'Adresse 1',
'address_2'=>'Adresse 2',
'city'=>'Stadt',
'state'=>'Zustand',
'country'=>'Land',
'postal'=>'Post',
'company'=>'Unternehmen',
'tax_id'=>'STEUER ID',
'contact'=>'Kontakt',
'price'=>'Preis',
];
