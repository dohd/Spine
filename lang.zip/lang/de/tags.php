<?php
return [
'name'=>'Verlinke den Namen',
'tags'=>'Stichworte',
'tag'=>'Etikett',
'new'=>'Neuer Tag',
'color'=>'Tag Farbe',
'select'=>'Wählen Sie Tag ..',
'new_status'=>'Neuer Status',
'tag_status'=>'Status & Tags',
];
