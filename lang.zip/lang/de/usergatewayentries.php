<?php
return [
'gateway'=>'Tor',
'enable'=>'Aktivieren',
'key1'=>'Schlüssel 1',
'key2'=>'Schlüssel 2',
'currency'=>'Währungscode',
'dev_mode'=>'Entwicklermodus',
'surcharge'=>'Zuschlag%',
'extra'=>'Andere',
'usergatewayentries'=>'Zahlungsgateways',
'usergatewayentry'=>'Zahlungs-Gateways',
'surcharge_applicable'=>'Zahlungsgateway-Zuschlag Gilt für den Gesamtbetrag',
];
