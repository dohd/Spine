<?php
return [
'name'=>'Name',
'color'=>'Farbe',
'section'=>'Sektion',
'miscs'=>'Tags & Status',
'misc'=>'Tag & Status',
];
