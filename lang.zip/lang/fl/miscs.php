<?php
return [
'name'=>'Pangalan',
'color'=>'Kulay',
'section'=>'Seksyon',
'miscs'=>'Mga Tag at Mga Katayuan',
'misc'=>'Tag at Katayuan',
];
