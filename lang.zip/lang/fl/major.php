<?php
return [
'address_1'=>'Address 1',
'address_2'=>'Alamat 2',
'city'=>'Lungsod',
'state'=>'Estado',
'country'=>'Bansa',
'postal'=>'Postal',
'company'=>'Kumpanya',
'tax_id'=>'TAX ID',
'contact'=>'Makipag-ugnay',
'price'=>'Presyo',
];
