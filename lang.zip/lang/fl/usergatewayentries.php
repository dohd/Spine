<?php
return [
'gateway'=>'Gateway',
'enable'=>'Enable',
'key1'=>'Key 1',
'key2'=>'Key 2',
'currency'=>'Currency Code',
'dev_mode'=>'Developer mode',
'surcharge'=>'Surcharge %',
'extra'=>'Other',
'usergatewayentries'=>'Payment Gateways',
'usergatewayentry'=>'Gateway ng Bayad',
'surcharge_applicable'=>'Pagbabayad ng Gateway ng Pagbabayad na Naaangkop sa kabuuang halaga',
];
