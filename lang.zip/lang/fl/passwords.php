<?php
return [
'password'=>'Ang mga password ay dapat na hindi bababa sa anim na mga character at tumutugma sa kumpirmasyon.',
'reset'=>'Na-reset ang iyong password!',
'sent'=>'Na-e-mail namin ang iyong link sa pag-reset ng password!',
'token'=>'Hindi wasto ang token ng pag-reset ng password na ito.',
'user'=>'Maaari kaming "makahanap ng isang gumagamit gamit ang e-mail address.',
];
