<?php
return [
'title'=>'Pangalan',
'summary'=>'Buod',
'disc_rate'=>'Rate ng Diskwento ng Grupo',
'members'=>'Mga kasapi',
'group_message'=>'Magpadala ng mensahe ng pangkat',
];
