<?php
return [
'previous'=>'«Nakaraan',
'next'=>'Susunod »',
];
