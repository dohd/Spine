<?php
return [
'class'=>'klase',
'module'=>'Modyul',
'value'=>'Halaga',
'note'=>'Tandaan',
'prefixes'=>'Mga Pang-unay',
'prefix'=>'Awitan',
'invoice'=>'Invoice',
'delivery_note'=>'Talaan ng Paghahatid',
'proforma_invoice'=>'Proforma Invoice',
'payment_receipt'=>'Resibo',
'quotes'=>'Mga Quote',
'subscriptions'=>'Mga subscription',
'credit_note'=>'Tala ng Kredito',
'stock_return'=>'Pagbabalik ng Stock',
'purchase_order'=>'Order ng Pagbili',
'POS'=>'POS Point Ng Pagbebenta',
];
