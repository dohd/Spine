<?php
return [
'name'=>'Pangalan',
'note'=>'Tandaan',
'departments'=>'Mga kagawaran',
'department'=>'Kagawaran',
];
