<?php
return [
'module_id'=>'Modyul',
'field_type'=>'Uri ng Patlang',
'name'=>'Pangalan',
'placeholder'=>'Placeholder',
'default_data'=>'Default na Data',
'field_view'=>'View ng Patlang',
'customfields'=>'Pasadyang mga patlang',
'customfield'=>'Pasadyang bukid',
'text'=>'Teksto',
'public'=>'Pampubliko',
'private'=>'Pribado',
];
