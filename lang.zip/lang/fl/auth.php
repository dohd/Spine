<?php 
return [
  'failed' => 'Ang mga kredensyal na ito ay hindi tumutugma sa aming mga talaan.',
  'general_error' => 'Wala kang access upang gawin iyon.',
  'throttle' => 'Napakaraming mga pagtatangka sa pag-login. Mangyaring subukang muli sa: segundo segundo.',
  'unknown' => 'Isang hindi kilalang error ang naganap',
];