<?php
return [
'title'=>'Kategorya',
'extra'=>'Paglalarawan',
'sub_category'=>'Sub Category',
'sub_categories'=>'Mga kategorya ng Sub',
'total_products'=>'Kabuuang mga Produkto',
'total_worth'=>'Kabuuang Worth',
'c_type'=>'Uri ng kategorya',
'rel_id'=>'Category ng Magulang',
'parent'=>'Magulang',
'child'=>'Bata',
'productcategories'=>'Mga kategorya ng Produkto',
'valid_enter'=>'Mangyaring pumili ng isang wastong kategorya ng Produkto!',
];
