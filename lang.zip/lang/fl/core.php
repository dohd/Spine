<?php
return [
'home'=>'Bahay',
'plans'=>'Plano',
'blog'=>'Blog',
'about'=>'Tungkol sa',
'contact'=>'Makipag-ugnay',
'register_now'=>'Mag-rehistro na ngayon',
'pricing_plans'=>'Ang aming mga plano sa pagpepresyo',
'sign_up'=>'Mag-sign Up',
'subscribe'=>'Mag-subscribe',
'renew'=>'Pag-update ng Plano',
'subscribe_exist'=>'Na-subscribe mo na ang planong ito!',
'make_payment'=>'Gumawa ng Pagbabayad upang kumpirmahin ang subscription',
];
