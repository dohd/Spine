<?php
return [
'warehouse'=>'Bodega',
'warehouse_default'=>'Default Warehouse',
'warehouses'=>'Bodega',
'title'=>'Pangalan ng WareHouse',
'extra'=>'Paglalarawan ng WareHouse',
'valid_enter'=>'Mangyaring pumili ng isang wastong bodega!',
];
