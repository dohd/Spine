<?php
return [
'name'=>'Pangalan ng account',
'bank'=>'bangko',
'number'=>'Numero ng account sa bangko',
'code'=>'Code ng account',
'note'=>'Tandaan',
'address'=>'Pangalan ng Sangay',
'branch'=>'Sangay',
'enable'=>'Paganahin',
'banks'=>'Mga Account sa Bank',
'payable_accounts'=>'Mga Bayad na Bayad',
];
