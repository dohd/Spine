<?php
return [
'module_id'=>'মডিউল',
'field_type'=>'ক্ষেত্র প্রকার',
'name'=>'নাম',
'placeholder'=>'প্লেসহোল্ডার',
'default_data'=>'ডিফল্ট ডেটা',
'field_view'=>'ফিল্ড ভিউ',
'customfields'=>'অস্ত্রোপচার',
'customfield'=>'কাস্টম ক্ষেত্র',
'text'=>'পাঠ',
'public'=>'প্রকাশ্য',
'private'=>'ব্যক্তিগত',
];
