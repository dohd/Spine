<?php
return [
'address_1'=>'ঠিকানা 1',
'address_2'=>'ঠিকানা ২',
'city'=>'শহর',
'state'=>'রাষ্ট্র',
'country'=>'দেশ',
'postal'=>'পোস্টাল',
'company'=>'প্রতিষ্ঠান',
'tax_id'=>'ট্যাক্স আইডি',
'contact'=>'যোগাযোগ',
'price'=>'মূল্য',
];
