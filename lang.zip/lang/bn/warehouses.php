<?php
return [
'warehouse'=>'গুদাম',
'warehouse_default'=>'ডিফল্ট গুদাম',
'warehouses'=>'গুদাম',
'title'=>'গুদামের নাম',
'extra'=>'গুদামঘর বর্ণনা',
'valid_enter'=>'একটি বৈধ গুদাম নির্বাচন করুন!',
];
