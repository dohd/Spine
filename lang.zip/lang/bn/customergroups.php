<?php
return [
'title'=>'নাম',
'summary'=>'সারসংক্ষেপ',
'disc_rate'=>'গ্রুপ ছাড়ের হার',
'members'=>'সদস্য',
'group_message'=>'গ্রুপ বার্তা প্রেরণ করুন',
];
