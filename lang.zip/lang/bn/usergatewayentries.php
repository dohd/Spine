<?php
return [
'gateway'=>'প্রবেশপথ',
'enable'=>'সক্ষম করা',
'key1'=>'কী 1',
'key2'=>'কী 2',
'currency'=>'মুদ্রা কোড',
'dev_mode'=>'বিকাশকারী মোড',
'surcharge'=>'সারচার্জ%',
'extra'=>'অন্যান্য',
'usergatewayentries'=>'পেমেন্ট গেটওয়েস',
'usergatewayentry'=>'পেমেন্ট গেটওয়ে',
'surcharge_applicable'=>'পেমেন্ট গেটওয়ে সারচার্জ মোট পরিমাণে প্রযোজ্য',
];
