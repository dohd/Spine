<?php
return [
'management'=>'ক্রয় আদেশ',
'tid'=>'ক্রয় আদেশ সংখ্যা',
'invoicedate'=>'অর্ডার তারিখ',
'invoiceduedate'=>'আদেশ দিন তারিখ নিশ্চিত',
'search_supplier'=>'সরবরাহকারী অনুসন্ধান করুন',
'supplier_details'=>'সরবরাহকারী বিশদ',
'supplier_search'=>'অনুসন্ধানের জন্য সরবরাহকারীর নাম বা মোবাইল নম্বর প্রবেশ করান',
'add_supplier'=>'সরবরাহকারী যুক্ত করুন',
'properties'=>'প্রোপার্টি',
'bill_from'=>'বিল থেকে',
'payment_for_order'=>'ক্রয় আদেশের জন্য অর্থ প্রদান',
'purchaseorders'=>'ক্রয় আদেশ',
'purchaseorder'=>'ক্রয় আদেশ',
];
