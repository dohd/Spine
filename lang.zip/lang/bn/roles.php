<?php
return [
'administrator'=>'প্রশাসক',
'user'=>'ব্যবহারকারী',
];
