<?php
return [
'name'=>'নাম',
'code'=>'কোড',
'type'=>'আদর্শ',
'val'=>'মান',
'rid'=>'সম্পর্কিত',
'unit_default'=>'ডিফল্ট ইউনিট',
'productvariables'=>'পণ্য ইউনিট পরিবর্তনশীল',
'productvariable'=>'পণ্য ইউনিট পরিবর্তনশীল',
'standard_type'=>'স্ট্যান্ডার্ড প্রকার - একক ইউনিট',
'multiple_type'=>'একাধিক প্রকার - একাধিক ইউনিট',
];
