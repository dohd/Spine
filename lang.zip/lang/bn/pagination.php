<?php
return [
'previous'=>'" আগে',
'next'=>'পরবর্তী "',
];
