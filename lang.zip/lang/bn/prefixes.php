<?php
return [
'class'=>'শ্রেণী',
'module'=>'মডিউল',
'value'=>'মান',
'note'=>'বিঃদ্রঃ',
'prefixes'=>'উপসর্গ',
'prefix'=>'উপসর্গ',
'invoice'=>'চালান',
'delivery_note'=>'চালান পত্র',
'proforma_invoice'=>'প্রোফর্মমা চালান',
'payment_receipt'=>'প্রাপ্তি রশিদ',
'quotes'=>'দর',
'subscriptions'=>'সাবস্ক্রিপশন',
'credit_note'=>'ক্রেডিট নোট',
'stock_return'=>'স্টক রিটার্নস',
'purchase_order'=>'ক্রয় আদেশ',
'POS'=>'বিক্রয় পস পয়েন্ট',
];
