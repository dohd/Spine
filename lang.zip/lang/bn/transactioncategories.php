<?php
return [
'name'=>'নাম',
'transactioncategories'=>'লেনদেন বিভাগ',
'transactioncategory'=>'লেনদেন বিভাগ',
'valid_enter'=>'একটি বৈধ লেনদেন বিভাগ নির্বাচন করুন!',
];
