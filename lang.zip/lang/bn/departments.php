<?php
return [
'name'=>'নাম',
'note'=>'বিঃদ্রঃ',
'departments'=>'বিভাগ',
'department'=>'বিভাগ',
];
