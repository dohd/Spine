<?php
return [
'title'=>'বিভাগ',
'extra'=>'বিবরণ',
'sub_category'=>'উপ বিভাগ',
'sub_categories'=>'উপ বিভাগ',
'total_products'=>'মোট পণ্য',
'total_worth'=>'মোট মূল্যবান',
'c_type'=>'বিভাগের প্রকার',
'rel_id'=>'মূল বিভাগ',
'parent'=>'মাতা',
'child'=>'শিশু',
'productcategories'=>'পণের ধরন',
'valid_enter'=>'একটি বৈধ পণ্য বিভাগ নির্বাচন করুন!',
];
