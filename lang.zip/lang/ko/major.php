<?php
return [
'address_1'=>'주소 1',
'address_2'=>'주소 2',
'city'=>'시티',
'state'=>'상태',
'country'=>'국가',
'postal'=>'우편 엽서',
'company'=>'회사',
'tax_id'=>'세금 아이디',
'contact'=>'접촉',
'price'=>'가격',
];
