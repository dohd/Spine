<?php
return [
'title'=>'표제',
'type'=>'구성 단위',
'terms'=>'자귀',
'term'=>'기간',
'required'=>'지불 기간을 작성하고 선택하십시오!',
];
