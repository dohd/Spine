<?php
return [
'warehouse'=>'창고',
'warehouse_default'=>'기본 창고',
'warehouses'=>'창고',
'title'=>'창고 이름',
'extra'=>'창고 설명',
'valid_enter'=>'유효한 창고를 선택하십시오!',
];
