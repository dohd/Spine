<?php
return [
'name'=>'계정 이름',
'bank'=>'은행',
'number'=>'은행 계좌 번호',
'code'=>'계정 코드',
'note'=>'노트',
'address'=>'지점 주소',
'branch'=>'분기',
'enable'=>'사용',
'banks'=>'은행 계좌',
'payable_accounts'=>'채무 계정',
];
