<?php
return [
'previous'=>'" 이전',
'next'=>'다음 "',
];
