<?php
return [
'home'=>'집',
'plans'=>'계획',
'blog'=>'블로그',
'about'=>'약',
'contact'=>'접촉',
'register_now'=>'지금 등록하세요',
'pricing_plans'=>'우리의 가격 계획',
'sign_up'=>'가입하기',
'subscribe'=>'구독',
'renew'=>'계획 갱신',
'subscribe_exist'=>'이 계획을 이미 구독하셨습니다!',
'make_payment'=>'구독 확인을 위해 결제',
];
