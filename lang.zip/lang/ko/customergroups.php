<?php
return [
'title'=>'이름',
'summary'=>'요약',
'disc_rate'=>'단체 할인율',
'members'=>'회원',
'group_message'=>'그룹 메시지 보내기',
];
