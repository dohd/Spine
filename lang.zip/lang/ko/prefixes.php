<?php
return [
'class'=>'수업',
'module'=>'구성 단위',
'value'=>'값',
'note'=>'노트',
'prefixes'=>'접두사',
'prefix'=>'접두사',
'invoice'=>'송장',
'delivery_note'=>'납품서',
'proforma_invoice'=>'견적 송장',
'payment_receipt'=>'영수증',
'quotes'=>'인용 부호',
'subscriptions'=>'구독',
'credit_note'=>'신용 노트',
'stock_return'=>'재고 반품',
'purchase_order'=>'구매 오더',
'POS'=>'POS 판매 시점',
];
