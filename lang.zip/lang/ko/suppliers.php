<?php
return [
'management'=>'공급 업체 관리',
'suppliers'=>'공급 업체',
'supplier'=>'공급 업체',
'valid_enter'=>'유효한 공급 업체를 선택하십시오!',
];
