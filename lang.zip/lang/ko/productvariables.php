<?php
return [
'name'=>'이름',
'code'=>'암호',
'type'=>'유형',
'val'=>'값',
'rid'=>'와 연관되다',
'unit_default'=>'기본 단위',
'productvariables'=>'제품 단위 변수',
'productvariable'=>'제품 단위 변수',
'standard_type'=>'표준 유형-단일 장치',
'multiple_type'=>'다중 유형-다중 장치',
];
