<?php
return [
'title'=>'범주',
'extra'=>'기술',
'sub_category'=>'하위 카테고리',
'sub_categories'=>'하위 카테고리',
'total_products'=>'총 제품',
'total_worth'=>'총 가치',
'c_type'=>'카테고리 유형',
'rel_id'=>'상위 카테고리',
'parent'=>'부모의',
'child'=>'아이',
'productcategories'=>'제품 카테고리',
'valid_enter'=>'유효한 제품 카테고리를 선택하십시오!',
];
