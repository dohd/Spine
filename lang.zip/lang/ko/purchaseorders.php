<?php
return [
'management'=>'구매 주문',
'tid'=>'구매 주문 번호',
'invoicedate'=>'주문 날짜',
'invoiceduedate'=>'주문 확인 날짜',
'search_supplier'=>'공급 업체 검색',
'supplier_details'=>'공급 업체 세부 사항',
'supplier_search'=>'검색 할 공급 업체 이름 또는 휴대폰 번호를 입력하십시오',
'add_supplier'=>'공급 업체 추가',
'properties'=>'속성',
'bill_from'=>'청구서',
'payment_for_order'=>'구매 오더에 대한 지불',
'purchaseorders'=>'구매 주문',
'purchaseorder'=>'구매 오더',
];
