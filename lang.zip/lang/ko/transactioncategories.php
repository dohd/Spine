<?php
return [
'name'=>'이름',
'transactioncategories'=>'거래 카테고리',
'transactioncategory'=>'거래 카테고리',
'valid_enter'=>'유효한 거래 카테고리를 선택하십시오!',
];
