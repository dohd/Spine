<?php
return [
'name'=>'이름',
'color'=>'색깔',
'section'=>'부분',
'miscs'=>'태그 및 상태',
'misc'=>'태그 및 상태',
];
