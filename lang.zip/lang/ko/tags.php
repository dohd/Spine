<?php
return [
'name'=>'태그 이름',
'tags'=>'태그',
'tag'=>'꼬리표',
'new'=>'새 태그',
'color'=>'태그 색상',
'select'=>'태그를 선택하십시오.',
'new_status'=>'새로운 상태',
'tag_status'=>'상태 및 태그',
];
