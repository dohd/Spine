<?php
return [
'administrator'=>'관리자',
'user'=>'사용자',
];
