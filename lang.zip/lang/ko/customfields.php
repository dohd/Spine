<?php
return [
'module_id'=>'구성 단위',
'field_type'=>'필드 타입',
'name'=>'이름',
'placeholder'=>'자리 표시 자',
'default_data'=>'기본 데이터',
'field_view'=>'필드 뷰',
'customfields'=>'맞춤 입력란',
'customfield'=>'사용자 정의 필드',
'text'=>'본문',
'public'=>'공공의',
'private'=>'은밀한',
];
