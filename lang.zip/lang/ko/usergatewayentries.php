<?php
return [
'gateway'=>'게이트웨이',
'enable'=>'사용',
'key1'=>'키 1',
'key2'=>'키 2',
'currency'=>'통화 코드',
'dev_mode'=>'개발자 모드',
'surcharge'=>'할증료 %',
'extra'=>'다른',
'usergatewayentries'=>'결제 게이트웨이',
'usergatewayentry'=>'결제 게이트웨이',
'surcharge_applicable'=>'결제 게이트웨이 추가 요금 총액에 적용',
];
