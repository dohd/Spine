<?php
return [
'name'=>'이름',
'note'=>'노트',
'departments'=>'부서',
'department'=>'학과',
];
