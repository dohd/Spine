<?php
return [
'class'=>'kelas',
'module'=>'Modul',
'value'=>'Nilai',
'note'=>'Cathetan',
'prefixes'=>'Prefiks',
'prefix'=>'Awalan',
'invoice'=>'Invoice',
'delivery_note'=>'Cathetan Pangiriman',
'proforma_invoice'=>'Invoice Proforma',
'payment_receipt'=>'Resi Pambayaran',
'quotes'=>'Kutipan',
'subscriptions'=>'Langganan',
'credit_note'=>'Cathetan Kredit',
'stock_return'=>'Returns Simpenan',
'purchase_order'=>'Pesenan Tuku',
'POS'=>'Dijual POS Point',
];
