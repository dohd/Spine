<?php
return [
'warehouse'=>'Gudang',
'warehouse_default'=>'Gudang Default',
'warehouses'=>'Gudang',
'title'=>'Jeneng WareHouse',
'extra'=>'Katrangan WareHouse',
'valid_enter'=>'Mangga pilih gudang sing bener!',
];
