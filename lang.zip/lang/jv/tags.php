<?php
return [
'name'=>'Jeneng Tag',
'tags'=>'Tags',
'tag'=>'Tag',
'new'=>'Tag Anyar',
'color'=>'Werna Tag',
'select'=>'Pilih Tag ..',
'new_status'=>'Status Anyar',
'tag_status'=>'Status & Tag',
];
