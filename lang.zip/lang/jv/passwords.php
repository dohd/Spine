<?php
return [
'password'=>'Tembung sandhi kudu paling ora enem karakter lan cocog karo konfirmasi.',
'reset'=>'Tembung sandhi wis pulih!',
'sent'=>'Kita wis dikirim email reset link sandhi!',
'token'=>'Tandha sandhi sandhi iki ora bener.',
'user'=>'Kita ora bisa nemokake pangguna nganggo alamat e-mail kasebut.',
];
