<?php
return [
'name'=>'Jeneng',
'color'=>'Werna',
'section'=>'Bagean',
'miscs'=>'Tags & Status',
'misc'=>'Tag & Status',
];
