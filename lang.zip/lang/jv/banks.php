<?php
return [
'name'=>'Jeneng akun',
'bank'=>'Bank',
'number'=>'Nomer Akun Bank',
'code'=>'Kode Akun',
'note'=>'Cathetan',
'address'=>'Alamat Branch',
'branch'=>'Cabang',
'enable'=>'Aktifake',
'banks'=>'Akun Bank',
'payable_accounts'=>'Akun sing Bayar',
];
