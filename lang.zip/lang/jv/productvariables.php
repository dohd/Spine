<?php
return [
'name'=>'Jeneng',
'code'=>'Kode',
'type'=>'Ketik',
'val'=>'Nilai',
'rid'=>'Gegayutan karo',
'unit_default'=>'Unit Default',
'productvariables'=>'Variabel Unit Produk',
'productvariable'=>'Variabel Unit Produk',
'standard_type'=>'Tipe standar - Unit Tunggal',
'multiple_type'=>'Jinis Multiple - Unit Multiple',
];
