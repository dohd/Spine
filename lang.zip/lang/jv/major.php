<?php
return [
'address_1'=>'Alamat 1',
'address_2'=>'Alamat 2',
'city'=>'Kutha',
'state'=>'Negara',
'country'=>'Negara',
'postal'=>'Pos',
'company'=>'Perusahaan',
'tax_id'=>'ID TAX',
'contact'=>'Hubungi',
'price'=>'Rega',
];
