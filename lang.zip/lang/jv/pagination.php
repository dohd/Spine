<?php
return [
'previous'=>'«Sadurunge',
'next'=>'Sabanjure »',
];
