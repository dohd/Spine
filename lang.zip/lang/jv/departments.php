<?php
return [
'name'=>'Jeneng',
'note'=>'Cathetan',
'departments'=>'Departemen',
'department'=>'Departemen',
];
