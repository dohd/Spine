<?php
return [
'module_id'=>'Modul',
'field_type'=>'Jinis lapangan',
'name'=>'Jeneng',
'placeholder'=>'Placeholder',
'default_data'=>'Data Default',
'field_view'=>'Tampilan lapangan',
'customfields'=>'Kothak Custom',
'customfield'=>'Lapangan khusus',
'text'=>'Teks',
'public'=>'Publik',
'private'=>'Pribadi',
];
