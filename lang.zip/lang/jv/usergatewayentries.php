<?php
return [
'gateway'=>'Gateway',
'enable'=>'Aktifake',
'key1'=>'Kunci 1',
'key2'=>'Kunci 2',
'currency'=>'Kode Mata Wang',
'dev_mode'=>'Mode pangembang',
'surcharge'=>'Suku%',
'extra'=>'Liyane',
'usergatewayentries'=>'Gateway Pembayaran',
'usergatewayentry'=>'Gateway Pembayaran',
'surcharge_applicable'=>'Tuku Gateway Pembayaran ditrapake kanthi jumlah',
];
