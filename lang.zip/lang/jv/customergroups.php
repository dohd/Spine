<?php
return [
'title'=>'Jeneng',
'summary'=>'Ringkesan',
'disc_rate'=>'Tarif Diskon Group',
'members'=>'Anggota',
'group_message'=>'Kirim pesen grup',
];
