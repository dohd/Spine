<?php
return [
'name'=>'Jeneng',
'transactioncategories'=>'Kategori transaksi',
'transactioncategory'=>'Kategori Transaksi',
'valid_enter'=>'Mangga pilih kategori Transaksi sing sah!',
];
