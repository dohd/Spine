<?php
return [
'home'=>'Omah',
'plans'=>'Rencana',
'blog'=>'Blog',
'about'=>'Babagan',
'contact'=>'Hubungi',
'register_now'=>'Ndhaptar Saiki',
'pricing_plans'=>'Rencana rega',
'sign_up'=>'Mlebu',
'subscribe'=>'Langganan',
'renew'=>'Rencana nganyari',
'subscribe_exist'=>'Sampeyan wis ndhaptar rencana iki!',
'make_payment'=>'Priksa Pembayaran kanggo konfirmasi lengganan',
];
